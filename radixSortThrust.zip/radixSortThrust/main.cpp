
#include <iostream>
#include "radixSortThrust.h"

#include <thrust/host_vector.h>
#include <thrust/device_vector.h>
#include <thrust/sort.h>
#include <thrust/copy.h>
#include <thrust/sequence.h>
#include <thrust/random.h>
#include <thrust/generate.h>
#include <thrust/detail/type_traits.h>

#include <helper_cuda.h>

#include <cuda_runtime.h>

#include <algorithm>
#include <time.h>
#include <limits.h>

int readDetection(const char *filename, std::vector<float> &bbox, thrust::host_vector<float> &h_scores)
{
    printf("Start open file: %s\n", filename);
    std::FILE *fp;
    int cnt;
    float x, y, w, score;
    int nDetection = 0;
    fp = std::fopen(filename, "r");
    if (!fp)
    {
        printf("Error: unable to open file: %s", filename);
        return 0;
    }
    while (!std::feof(fp))
    {
        cnt = std::fscanf(fp, "%f,%f,%f,%f\n", &x, &y, &w, &score);
        if (cnt != 4)
        {
            printf("Error: Invalide file format inline %d when reading file %s", nDetection, filename);
            return 0;
        }
        bbox.push_back(x);
        bbox.push_back(y);
        bbox.push_back(w);
        bbox.push_back(w);
        h_scores.push_back(score);
    }
    std::fclose(fp);
    return 1;
}

__global__ void nms_cuda(float *bbox, float *score, uint *index, uint sizeOfIndex, float IOU)
{
}

/**
 * @brief
 *
 * @param bbox
 * @param index
 * @param iouMask
 * @param sizeOfIndex
 * @param IOU
 * @return __global__
 */
__global__ void IOU(float *bbox, uint *index, uint *iouMask, uint sizeOfIndex, float IOU)
{
    uint til_x = threadIdx.x + blockIdx.x * blockDim.x;
    uint til_y = threadIdx.y + blockIdx.y * blockDim.y;
    for (uint i = til_x; i < sizeOfIndex; i += blockDim.x * gridDim.x)
    {
        for (uint j = til_y; j < sizeOfIndex; j += blockDim.y * gridDim.y)
        {
            int iIndex = index[i];
            int jIndex = index[j];
            // float xiMin = bbox[i * 4];
            // float yiMin = bbox[i * 4 + 1];
            // float xiMax = bbox[i * 4] + bbox[i * 4 + 2];
            // float yiMax = bbox[i * 4 + 1] + bbox[i * 4 + 3];

            // float xjMin = bbox[j * 4];
            // float yjMin = bbox[j * 4 + 1];
            // float xjMax = bbox[j * 4] + bbox[j * 4 + 2];
            // float yjMax = bbox[j * 4 + 1] + bbox[j * 4 + 3];

            // Intersect
            float w = max(0.0f, min(bbox[iIndex * 4] + bbox[iIndex * 4 + 2], bbox[jIndex * 4] + bbox[jIndex * 4 + 2]) - max(bbox[iIndex * 4], bbox[jIndex * 4]) + 1.0f);
            float h = max(0.0f, min(bbox[iIndex * 4 + 1] + bbox[iIndex * 4 + 3], bbox[jIndex * 4 + 1] + bbox[jIndex * 4 + 3]) - max(bbox[iIndex * 4 + 1], bbox[jIndex * 4 + 1]) + 1.0f);

            // Union
            float xmin = max(0.0f, min(bbox[iIndex * 4], bbox[jIndex * 4]));
            float ymin = max(0.0f, min(bbox[iIndex * 4 + 1], bbox[jIndex * 4 + 1]));
            float xmax = max(0.0f, max(bbox[iIndex * 4] + bbox[iIndex * 4 + 2], bbox[jIndex * 4] + bbox[jIndex * 4 + 2]));
            float ymax = max(0.0f, max(bbox[iIndex * 4 + 1] + bbox[iIndex * 4 + 3], bbox[jIndex * 4 + 1] + bbox[jIndex * 4 + 3]));

            iouMask[i * sizeOfIndex + j] = (((w * h) / ((xmax - xmin) * (ymax - ymin) - w * h)) < IOU);
            // printf("iIndex: %d, jIndex: %d, value: %d\n", i, j, iouMask[i * sizeOfIndex + j]);
        }
    }
}

__global__ void confFilter(float *conf, uint *index, uint *confMask, uint sizeOfIndex, float confThreshold)
{
    uint til_x = threadIdx.x + blockIdx.x * blockDim.x;
    uint til_y = threadIdx.y + blockIdx.y * blockDim.y;
    for (uint i = til_x; i < sizeOfIndex; i += blockDim.x * gridDim.x)
    {
        for (uint j = til_y; j < sizeOfIndex; j += blockDim.y * gridDim.y)
        {
            int iIndex = index[i];
            int jIndex = index[j];
            confMask[i * sizeOfIndex + j] = conf[iIndex] < conf[jIndex];
        }
    }
}

int main(int argc, char **argv)
{
    std::vector<float> bbox;
    thrust::host_vector<float> h_scores, h_scoresSorted;
    thrust::host_vector<unsigned int> h_values, h_valuesSorted;

    thrust::device_vector<float> d_scores, d_scoresSorted;
    thrust::device_vector<unsigned int> d_values, d_valuesSorted;

    // Read data
    int h_err = readDetection(argv[1], bbox, h_scores);

    float *d_bbox;
    cudaMalloc((void **)&d_bbox, bbox.size() * sizeof(float));
    cudaMemcpy(d_bbox, bbox.data(), bbox.size() * sizeof(float), cudaMemcpyHostToDevice);

    printf("End detection:  Number of line: %d\n", h_scores.size());
    h_values = thrust::host_vector<unsigned int>(h_scores.size());
    h_scoresSorted = thrust::host_vector<float>(h_scores.size());
    h_valuesSorted = thrust::host_vector<unsigned int>(h_scores.size());

    printf("bbox: %d", h_scores.size());
    thrust::sequence(h_values.begin(), h_values.end());
    cudaEvent_t start_event, stop_event;
    checkCudaErrors(cudaEventCreate(&start_event));
    checkCudaErrors(cudaEventCreate(&stop_event));
    d_scores = h_scores;
    d_values = h_values;

    checkCudaErrors(cudaEventRecord(start_event, 0));

    thrust::sort_by_key(d_scores.begin(), d_scores.end(), d_values.begin(), thrust::greater<float>());

    checkCudaErrors(cudaEventRecord(stop_event, 0));
    checkCudaErrors(cudaEventSynchronize(stop_event));

    float time = 0;
    checkCudaErrors(cudaEventElapsedTime(&time, start_event, stop_event));
    time /= (1.0e3f);
    printf("Time: %.5f s\n", time);

    thrust::copy(d_scores.data(), d_scores.data() + h_scoresSorted.size(), h_scoresSorted.begin());
    thrust::copy(d_values.data(), d_values.data() + h_scoresSorted.size(), h_valuesSorted.begin());

    uint sizeOfIndex = 30;
    dim3 grid(2, 2, 1);
    dim3 block(2, 2, 1);
    uint *iouMask, *confMask, *andMask;
    cudaMalloc((void **)&iouMask, sizeof(uint) * sizeOfIndex * sizeOfIndex);
    cudaMalloc((void **)&confMask, sizeof(uint) * sizeOfIndex * sizeOfIndex);
    cudaMalloc((void **)&andMask, sizeof(uint) * sizeOfIndex * sizeOfIndex);
    IOU<<<grid, block>>>((float *)d_bbox, thrust::raw_pointer_cast(d_values.data()), iouMask, sizeOfIndex, 0.3f);

    confFilter<<<grid, block>>>(thrust::raw_pointer_cast(d_scores.data()), thrust::raw_pointer_cast(d_values.data()), confMask, sizeOfIndex, 80.f);
    cudaDeviceSynchronize();

    // for(int i = 0; i < h_scores.size(); i++)
    // {
    //     printf("Index: %d, before sorting: %f, after sorting value: %f, after sorting order: %d\n", i, h_scores.data()[i], h_scoresSorted.data()[i], h_valuesSorted.data()[i]);
    // }

    // // Start logs
    // printf("%s Starting...\n\n", argv[0]);

    // findCudaDevice(argc, (const char **)argv);

    // bool bTestResult = false;

    // if (checkCmdLineFlag(argc, (const char **)argv, "float"))
    //     bTestResult = testSort<float, true>(argc, argv);
    // else
    //     bTestResult = testSort<unsigned int, false>(argc, argv);

    // printf(bTestResult ? "Test passed\n" : "Test failed!\n");
    return 1;
}
