Sample: radixSortThrust
Minimum spec: SM 3.5

This sample demonstrates a very fast and efficient parallel radix sort uses Thrust library. The included RadixSort class can sort either key-value pairs (with float or unsigned integer keys) or keys only.

Key concepts:
Data-Parallel Algorithms
Performance Strategies
